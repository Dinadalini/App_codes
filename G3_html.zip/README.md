# App_codes

Aplicativo para busca de rotas de preferência do usuário. Este, por sua vez, pode adicionar paradas ou optar pela rota de sua preferência de acordo com os diferentes filtros.